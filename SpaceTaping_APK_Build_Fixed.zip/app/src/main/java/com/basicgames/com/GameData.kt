package com.basicgames.com

import android.content.Context

data class BallSkin(
    val name: String,
    val cost: Int,
    val c1: Int,
    val c2: Int,
    val c3: Int,
    val glow: Int,
    val tagline: String
)

object GameData {
    val skins = listOf(
        BallSkin("COSMIC", 0, 0xFFFFFFFF.toInt(), 0xFF76D9FF.toInt(), 0xFF2D4CFF.toInt(), 0xFF78E6FF.toInt(), "The first spark"),
        BallSkin("NEON", 35, 0xFFFFFFFF.toInt(), 0xFF39FFE8.toInt(), 0xFF1266FF.toInt(), 0xFF2CFFF0.toInt(), "Electric velocity"),
        BallSkin("PLASMA", 80, 0xFFFFFFFF.toInt(), 0xFFFFB43B.toInt(), 0xFFFF294D.toInt(), 0xFFFF425C.toInt(), "Solar ignition"),
        BallSkin("GALAXY", 140, 0xFFFFFFFF.toInt(), 0xFFB47CFF.toInt(), 0xFF5B20D8.toInt(), 0xFFB870FF.toInt(), "A universe in motion"),
        BallSkin("BLACK HOLE", 230, 0xFFFFFFFF.toInt(), 0xFF59617A.toInt(), 0xFF05050C.toInt(), 0xFF8D5CFF.toInt(), "Gravity bends light"),
        BallSkin("SOLAR", 360, 0xFFFFFFFF.toInt(), 0xFFFFEA68.toInt(), 0xFFFF5B17.toInt(), 0xFFFF9A2E.toInt(), "Forged in a star"),
        BallSkin("ICE", 520, 0xFFFFFFFF.toInt(), 0xFFBDF6FF.toInt(), 0xFF4CA5FF.toInt(), 0xFFB7F4FF.toInt(), "Frozen velocity"),
        BallSkin("QUANTUM", 760, 0xFFFFFFFF.toInt(), 0xFFFF64D7.toInt(), 0xFF642DFF.toInt(), 0xFFFF6BE9.toInt(), "Beyond probability"),
        BallSkin("LEGENDARY", 1100, 0xFFFFFFFF.toInt(), 0xFFFFE8A8.toInt(), 0xFFFF5C9D.toInt(), 0xFFFFB86B.toInt(), "Born for the void")
    )

    fun prefs(c: Context) = c.getSharedPreferences("galactic_spin", Context.MODE_PRIVATE)
    fun best(c: Context) = prefs(c).getInt("best", 0)
    fun credits(c: Context) = prefs(c).getInt("credits", 0)
    fun equipped(c: Context) = prefs(c).getInt("equipped", 0).coerceIn(0, skins.lastIndex)

    fun unlocked(c: Context, i: Int): Boolean {
        if (i !in skins.indices) return false
        return i == 0 || prefs(c).getBoolean("unlocked_$i", false)
    }

    fun unlock(c: Context, i: Int): Boolean {
        if (i !in skins.indices || unlocked(c, i)) return unlocked(c, i)
        val p = prefs(c)
        val credits = p.getInt("credits", 0)
        val cost = skins[i].cost
        if (credits < cost) return false
        p.edit().putInt("credits", credits - cost).putBoolean("unlocked_$i", true).apply()
        return true
    }

    fun equip(c: Context, i: Int) {
        if (unlocked(c, i)) prefs(c).edit().putInt("equipped", i).apply()
    }

    fun saveRun(c: Context, score: Int) {
        val p = prefs(c)
        val oldBest = p.getInt("best", 0)
        val oldCredits = p.getInt("credits", 0)
        p.edit()
            .putInt("best", maxOf(oldBest, score))
            .putInt("credits", oldCredits + score)
            .apply()
    }
}
