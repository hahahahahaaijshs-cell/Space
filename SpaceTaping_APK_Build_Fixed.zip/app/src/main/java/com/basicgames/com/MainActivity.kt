package com.basicgames.com

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Vibrator
import android.os.VibrationEffect
import android.view.*
import kotlin.math.*

class MainActivity:Activity(){
    private lateinit var gl:GalaxyRenderer
    private lateinit var overlay:UiOverlay
    var screen=Screen.SPLASH
    var score=0
    var gameOver=false
    var paused=false
    var playerLane=0
    private var splashStart=System.currentTimeMillis()

    enum class Screen{SPLASH,MENU,GAME,SHOP,SETTINGS,GAMEOVER}

    override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=Color.rgb(6,7,19);window.navigationBarColor=Color.rgb(6,7,19)
        val frame=android.widget.FrameLayout(this)
        gl=GalaxyRenderer(this); overlay=UiOverlay(this)
        frame.addView(gl,android.widget.FrameLayout.LayoutParams(-1,-1)); frame.addView(overlay,android.widget.FrameLayout.LayoutParams(-1,-1))
        setContentView(frame); gl.renderMode=GLSurfaceView.RENDERMODE_CONTINUOUSLY
        overlay.postDelayed({if(screen==Screen.SPLASH){screen=Screen.MENU;overlay.invalidate()}},1500)
    }
    fun go(s:Screen){screen=s; paused=false; if(s==Screen.GAME){score=0;playerLane=0;gameOver=false;gl.resetGame()} overlay.invalidate()}
    fun haptic(){ if(GameData.prefs(this).getBoolean("haptics",true)){ val v=getSystemService(VIBRATOR_SERVICE) as Vibrator; if(android.os.Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(18,VibrationEffect.DEFAULT_AMPLITUDE)) else v.vibrate(18)}}
    fun earn(){ if(!gameOver){score++; if(score%10==0)haptic()} }

    inner class GalaxyRenderer(c:Context):GLSurfaceView(c){
        private val r=SceneRenderer(this@MainActivity)
        init{setEGLContextClientVersion(2);setRenderer(r);setRenderMode(RENDERMODE_CONTINUOUSLY)}
        fun resetGame(){r.reset()}
    }

    inner class UiOverlay(c:Context):View(c){
        private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val stars=ArrayList<PointF>(); private val rnd=java.util.Random(4); private var last=System.nanoTime(); private var tick=0L
        init{repeat(110){stars.add(PointF(rnd.nextFloat(),rnd.nextFloat()))};setLayerType(View.LAYER_TYPE_SOFTWARE,null)}
        override fun onDraw(c:Canvas){super.onDraw(c); val w=width.toFloat();val h=height.toFloat()
            drawAtmosphere(c,w,h)
            when(screen){Screen.SPLASH->drawSplash(c,w,h);Screen.MENU->drawMenu(c,w,h);Screen.GAME->drawHud(c,w,h);Screen.SHOP->drawShop(c,w,h);Screen.SETTINGS->drawSettings(c,w,h);Screen.GAMEOVER->drawGameOver(c,w,h)}
            if(screen==Screen.SPLASH){postInvalidateDelayed(50)} else if(screen==Screen.GAME){postInvalidateDelayed(50)}
        }
        private fun drawAtmosphere(c:Canvas,w:Float,h:Float){
            p.shader=LinearGradient(0f,0f,w,h,Color.rgb(5,7,18),Color.rgb(25,7,42),Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p);p.shader=null
            for((i,s) in stars.withIndex()){p.color=Color.WHITE;p.alpha=35+(i%5)*28;c.drawCircle(s.x*w,s.y*h,1f+(i%3)*.55f,p)};p.alpha=255
            val rg=RadialGradient(w*.5f,h*.44f,min(w,h)*.55f,Color.argb(40,55,130,255),Color.TRANSPARENT,Shader.TileMode.CLAMP);p.shader=rg;c.drawCircle(w*.5f,h*.44f,min(w,h)*.55f,p);p.shader=null
        }
        private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,align:Paint.Align=Paint.Align.CENTER,bold:Boolean=false){p.shader=null;p.color=color;p.textSize=size;p.textAlign=align;p.typeface=Typeface.create("sans",if(bold)Typeface.BOLD else Typeface.NORMAL);p.style=Paint.Style.FILL;c.drawText(s,x,y,p)}
        private fun glass(c:Canvas,l:Float,t:Float,r:Float,b:Float,stroke:Int=Color.argb(90,140,170,230)){p.color=Color.argb(105,12,15,34);p.setShadowLayer(22f,0f,10f,Color.argb(110,0,0,0));c.drawRoundRect(l,t,r,b,26f,26f,p);p.clearShadowLayer();p.style=Paint.Style.STROKE;p.strokeWidth=1.5f;p.color=stroke;c.drawRoundRect(l,t,r,b,26f,26f,p);p.style=Paint.Style.FILL}
        private fun button(c:Canvas,l:Float,t:Float,r:Float,b:Float,label:String,accent:Boolean=true){p.color=if(accent)Color.argb(225,42,120,245) else Color.argb(130,22,25,48);p.setShadowLayer(if(accent)20f else 10f,0f,8f,if(accent)Color.argb(100,40,150,255) else Color.TRANSPARENT);c.drawRoundRect(l,t,r,b,22f,22f,p);p.clearShadowLayer();p.style=Paint.Style.STROKE;p.strokeWidth=1.5f;p.color=if(accent)Color.argb(210,130,225,255) else Color.argb(100,145,160,205);c.drawRoundRect(l,t,r,b,22f,22f,p);p.style=Paint.Style.FILL;text(c,label,(l+r)/2,(t+b)/2+6f,16f,Color.WHITE,Paint.Align.CENTER,true)}
        private fun drawSplash(c:Canvas,w:Float,h:Float){text(c,"GALACTIC",w/2,h*.43f,40f,Color.WHITE,bold=true);text(c,"SPIN",w/2,h*.49f,25f,Color.rgb(110,210,255),bold=true);text(c,"ENTER THE ORBIT",w/2,h*.55f,12f,Color.rgb(155,165,205));p.color=Color.argb(90,80,190,255);c.drawCircle(w/2,h*.68f,3f+((System.currentTimeMillis()/100)%12),p)}
        private fun drawMenu(c:Canvas,w:Float,h:Float){text(c,"GALACTIC",28f,56f,27f,Color.WHITE,Paint.Align.LEFT,true);text(c,"SPIN",29f,80f,17f,Color.rgb(104,211,255),Paint.Align.LEFT,true);
            glass(c,w-128f,28f,w-22f,78f);text(c,"BEST",w-75f,49f,10f,Color.rgb(145,155,190));text(c,"${GameData.best(this@MainActivity)}",w-75f,68f,18f,Color.WHITE,bold=true)
            text(c,"ROTATE. SURVIVE. ASCEND.",w/2,h*.22f,12f,Color.rgb(145,158,200),bold=true);text(c,"A cosmic reflex challenge",w/2,h*.26f,15f,Color.rgb(200,205,230))
            button(c,w*.14f,h*.39f,w*.86f,h*.49f,"PLAY",true);button(c,w*.14f,h*.52f,w*.86f,h*.61f,"BALL SHOP",false);button(c,w*.14f,h*.64f,w*.86f,h*.73f,"SETTINGS",false)
            val credits=GameData.credits(this@MainActivity);text(c,"GALAXY CREDITS",w/2,h*.83f,10f,Color.rgb(120,135,175));text(c,"✦ $credits",w/2,h*.875f,20f,Color.rgb(120,225,255),bold=true);
            val best=GameData.best(this@MainActivity);val next=GameData.skins.drop(1).firstOrNull{it.cost>best};val prog=if(next==null)1f else (best.toFloat()/next.cost).coerceIn(0f,1f);text(c,"NEXT UNLOCK",w*.14f,h*.925f,9f,Color.rgb(120,135,175),Paint.Align.LEFT);p.color=Color.argb(80,100,130,180);c.drawRoundRect(w*.14f,h*.94f,w*.86f,h*.948f,6f,6f,p);p.color=Color.rgb(90,210,255);c.drawRoundRect(w*.14f,h*.94f,w*.14f+(w*.72f*prog),h*.948f,6f,6f,p)}
        private fun drawHud(c:Canvas,w:Float,h:Float){
            text(c,"SCORE",24f,48f,10f,Color.rgb(125,140,180),Paint.Align.LEFT,true);text(c,"$score",24f,73f,28f,Color.WHITE,Paint.Align.LEFT,true);text(c,"BEST ${GameData.best(this@MainActivity)}",w-24f,49f,11f,Color.rgb(150,160,195),Paint.Align.RIGHT);val level=1+score/10;text(c,"LEVEL $level",w-24f,72f,13f,Color.rgb(95,220,255),Paint.Align.RIGHT,true);
            if(paused){glass(c,w*.12f,h*.34f,w*.88f,h*.66f);text(c,"PAUSED",w/2,h*.43f,29f,Color.WHITE,bold=true);text(c,"Catch your breath.",w/2,h*.48f,13f,Color.rgb(155,165,200));button(c,w*.22f,h*.53f,w*.78f,h*.61f,"RESUME",true);button(c,w*.22f,h*.62f,w*.78f,h*.70f,"QUIT",false)} else {text(c,"TAP TO SHIFT ORBIT",w/2,h-36f,11f,Color.rgb(130,145,180),bold=true);p.color=Color.argb(80,80,190,255);c.drawCircle(w/2,h*.52f,min(w,h)*.39f,p);p.color=Color.TRANSPARENT}
        }
        private fun drawShop(c:Canvas,w:Float,h:Float){text(c,"BALL VAULT",24f,58f,28f,Color.WHITE,Paint.Align.LEFT,true);text(c,"COSMIC COLLECTION",24f,82f,11f,Color.rgb(125,145,190),Paint.Align.LEFT);text(c,"✦ ${GameData.credits(this@MainActivity)}",w-24f,62f,16f,Color.rgb(115,220,255),Paint.Align.RIGHT,true);
            val start=112f;val gap=105f;val selected=GameData.equipped(this@MainActivity);GameData.skins.forEachIndexed{i,s->val y=start+i*gap; if(y>h-45)return@forEachIndexed;glass(c,18f,y,w-18f,y+88f,if(i==selected)Color.argb(180,90,220,255) else Color.argb(70,130,145,190)); text(c,s.name,38f,y+31f,16f,Color.WHITE,Paint.Align.LEFT,true);text(c,s.tagline,38f,y+54f,10f,Color.rgb(145,155,190),Paint.Align.LEFT);val ok=GameData.unlocked(this@MainActivity,i);val state=if(i==selected)"EQUIPPED" else if(ok)"EQUIP" else "${s.cost} ✦";button(c,w-112f,y+20f,w-36f,y+66f,state,i==selected); }
            text(c,"Tap a ball to preview • locked balls require credits",w/2,h-18f,10f,Color.rgb(110,125,160))
        }
        private fun drawSettings(c:Canvas,w:Float,h:Float){text(c,"SETTINGS",24f,60f,29f,Color.WHITE,Paint.Align.LEFT,true);text(c,"SYSTEM CONTROL",24f,84f,11f,Color.rgb(125,145,190),Paint.Align.LEFT);val pfs=GameData.prefs(this@MainActivity);val sound=pfs.getBoolean("sound",true);val hap=pfs.getBoolean("haptics",true);listOf("SOUND" to sound,"HAPTICS" to hap).forEachIndexed{i,v->val y=145f+i*88f;glass(c,24f,y,w-24f,y+64f);text(c,v.first,48f,y+39f,15f,Color.WHITE,Paint.Align.LEFT,true);text(c,if(v.second)"ON" else "OFF",w-74f,y+39f,12f,if(v.second)Color.rgb(100,225,190) else Color.rgb(150,155,175),bold=true)};button(c,24f,h-115f,w-24f,h-45f,"BACK",false)}
        private fun drawGameOver(c:Canvas,w:Float,h:Float){glass(c,w*.10f,h*.24f,w*.90f,h*.78f);text(c,if(score>=GameData.best(this@MainActivity)&&score>0)"NEW BEST" else "RUN COMPLETE",w/2,h*.34f,13f,Color.rgb(100,225,255),bold=true);text(c,"$score",w/2,h*.46f,66f,Color.WHITE,bold=true);text(c,"SCORE",w/2,h*.50f,10f,Color.rgb(140,150,190),bold=true);text(c,"BEST ${maxOf(score,GameData.best(this@MainActivity))}   •   LEVEL ${1+score/10}",w/2,h*.56f,12f,Color.rgb(170,180,210));button(c,w*.18f,h*.63f,w*.82f,h*.71f,"RETRY",true);button(c,w*.18f,h*.73f,w*.82f,h*.81f,"MAIN MENU",false)}

        override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat()
            when(screen){Screen.SPLASH->{screen=Screen.MENU;invalidate()}
                Screen.MENU->{when{y in h*.36f..h*.51f->go(Screen.GAME);y in h*.50f..h*.63f->go(Screen.SHOP);y in h*.62f..h*.75f->go(Screen.SETTINGS)}}
                Screen.GAME->{if(paused){if(y in h*.51f..h*.62f){paused=false;invalidate()}else if(y in h*.61f..h*.72f)go(Screen.MENU)}else if(y<100f&&x>w-100f){paused=true;invalidate()}else{playerLane=1-playerLane;haptic();gl.requestRender()}}
                Screen.SHOP->{if(y<100f){go(Screen.MENU)}else{val idx=((y-112f)/105f).toInt();if(idx in GameData.skins.indices){if(GameData.unlocked(this@MainActivity,idx)){GameData.equip(this@MainActivity,idx);haptic();invalidate()}else if(GameData.unlock(this@MainActivity,idx)){GameData.equip(this@MainActivity,idx);haptic();invalidate()}}}}
                Screen.SETTINGS->{val pfs=GameData.prefs(this@MainActivity);when{y in 130f..220f->pfs.edit().putBoolean("sound",!pfs.getBoolean("sound",true)).apply();y in 220f..315f->pfs.edit().putBoolean("haptics",!pfs.getBoolean("haptics",true)).apply();y>h-135->go(Screen.MENU)};invalidate()}
                Screen.GAMEOVER->{when{y in h*.60f..h*.73f->go(Screen.GAME);y in h*.71f..h*.85f->go(Screen.MENU)}}}
            return true}
    }

    inner class SceneRenderer(private val a:MainActivity):android.opengl.GLSurfaceView.Renderer{
        private lateinit var sphere:Sphere;private var angle=0f;private var laser=0f;private var last=System.nanoTime();private var gameTimer=0L;private var dead=false;private var collisionCooldown=0f
        private var program=0;private var ringProgram=0;private val vp=FloatArray(16);private val proj=FloatArray(16);private val view=FloatArray(16);private val model=FloatArray(16);private val mvp=FloatArray(16)
        private val vertexShader="""attribute vec3 aPos; attribute vec3 aNormal; uniform mat4 uMVP; uniform mat4 uModel; varying vec3 vN; varying vec3 vP; void main(){vN=mat3(uModel)*aNormal;vP=(uModel*vec4(aPos,1.0)).xyz;gl_Position=uMVP*vec4(aPos,1.0);}"""
        private val fragShader="""precision mediump float; varying vec3 vN; varying vec3 vP; uniform vec3 uA; uniform vec3 uB; uniform vec3 uC; uniform vec3 uGlow; uniform float uTime; void main(){vec3 n=normalize(vN);vec3 l=normalize(vec3(-.5,.8,1.0));float d=max(dot(n,l),0.0);vec3 v=normalize(vec3(0.0,0.0,4.0)-vP);vec3 h=normalize(l+v);float spec=pow(max(dot(n,h),0.0),64.0);float rim=pow(1.0-max(dot(n,v),0.0),2.2);vec3 col=mix(uC,uB,d);col=mix(col,uA,.35+.25*d);col+=uGlow*(spec*1.25+rim*.35);gl_FragColor=vec4(col,1.0);}"""
        override fun onSurfaceCreated(g:javax.microedition.khronos.egl.EGLConfig?){android.opengl.GLES20.glClearColor(.02f,.025f,.07f,1f);program=makeProgram(vertexShader,fragShader);sphere=Sphere(34,22)}
        override fun onSurfaceChanged(g:javax.microedition.khronos.opengles.GL10?,w:Int,h:Int){android.opengl.GLES20.glViewport(0,0,w,h);android.opengl.Matrix.perspectiveM(proj,0,52f,w.toFloat()/h,1f,20f)}
        override fun onDrawFrame(g:javax.microedition.khronos.opengles.GL10?){val now=System.nanoTime();val dt=((now-last)/1e9).toFloat().coerceAtMost(.05f);last=now;android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT or android.opengl.GLES20.GL_DEPTH_BUFFER_BIT);android.opengl.GLES20.glEnable(android.opengl.GLES20.GL_DEPTH_TEST);android.opengl.Matrix.setLookAtM(view,0,0f,0f,5.3f,0f,0f,0f,0f,1f,0f);
            if(a.screen==Screen.GAME){angle+=dt*(1.0f+a.score/80f);laser+=dt*(.65f+a.score/55f);if(!dead){gameTimer+=(dt*1000).toLong();collisionCooldown-=dt;if(gameTimer>900){a.earn();gameTimer=0};val rel=sin(angle-laser);if(a.playerLane==1 && abs(rel)<0.095f && collisionCooldown<=0f){dead=true;collisionCooldown=1f;a.gameOver=true;GameData.saveRun(a,a.score);a.screen=Screen.GAMEOVER;a.overlay.invalidate();a.haptic()}};drawArena();drawObstacle();drawBall()}else{angle+=dt*.35f;drawArena();drawBall()}
        }
        fun reset(){gameTimer=0;angle=0f;laser=0f;dead=false;last=System.nanoTime()}
        private fun drawArena(){
            android.opengl.GLES20.glUseProgram(program); android.opengl.GLES20.glLineWidth(3f)
            val verts=FloatArray(48*3)
            for(i in 0 until 48){val t=i/48f*(2f*PI).toFloat();verts[i*3]=cos(t)*2.25f;verts[i*3+1]=sin(t)*2.25f;verts[i*3+2]=0f}
            val bb=java.nio.ByteBuffer.allocateDirect(verts.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();bb.put(verts).position(0)
            val pos=android.opengl.GLES20.glGetAttribLocation(program,"aPos"); val norm=android.opengl.GLES20.glGetAttribLocation(program,"aNormal")
            android.opengl.GLES20.glEnableVertexAttribArray(pos);android.opengl.GLES20.glVertexAttribPointer(pos,3,android.opengl.GLES20.GL_FLOAT,false,0,bb)
            android.opengl.Matrix.setIdentityM(model,0);android.opengl.Matrix.multiplyMM(mvp,0,view,0,model,0);android.opengl.Matrix.multiplyMM(mvp,0,proj,0,mvp,0)
            android.opengl.GLES20.glUniformMatrix4fv(android.opengl.GLES20.glGetUniformLocation(program,"uMVP"),1,false,mvp,0);android.opengl.GLES20.glUniformMatrix4fv(android.opengl.GLES20.glGetUniformLocation(program,"uModel"),1,false,model,0)
            fun rgb(x:Int)=floatArrayOf(((x shr 16)and 255)/255f,((x shr 8)and 255)/255f,(x and 255)/255f)
            val c=GameData.skins[GameData.equipped(a)]
            android.opengl.GLES20.glUniform3fv(android.opengl.GLES20.glGetUniformLocation(program,"uA"),1,rgb(c.glow),0);android.opengl.GLES20.glUniform3fv(android.opengl.GLES20.glGetUniformLocation(program,"uB"),1,rgb(c.c2),0);android.opengl.GLES20.glUniform3fv(android.opengl.GLES20.glGetUniformLocation(program,"uC"),1,rgb(c.c3),0);android.opengl.GLES20.glUniform3fv(android.opengl.GLES20.glGetUniformLocation(program,"uGlow"),1,rgb(c.glow),0)
            android.opengl.GLES20.glDrawArrays(android.opengl.GLES20.GL_LINE_LOOP,0,48);android.opengl.GLES20.glDisableVertexAttribArray(pos)
        }
        private fun drawBall(){android.opengl.Matrix.setIdentityM(model,0);val lane=if(a.playerLane==0).55f else .92f;android.opengl.Matrix.translateM(model,0,cos(angle)*lane,sin(angle)*lane,0f);android.opengl.Matrix.rotateM(model,0,angle*65f,0f,1f,0f);android.opengl.Matrix.scaleM(model,0,.43f,.43f,.43f);android.opengl.Matrix.multiplyMM(mvp,0,view,0,model,0);android.opengl.Matrix.multiplyMM(mvp,0,proj,0,mvp,0);val s=GameData.skins[GameData.equipped(a)];sphere.draw(program,mvp,model,s.c1,s.c2,s.c3,s.glow)}
        private fun drawObstacle(){android.opengl.Matrix.setIdentityM(model,0);android.opengl.Matrix.rotateM(model,0,laser*57.2958f,0f,0f,1f);android.opengl.Matrix.translateM(model,0,0f,1.18f,0f);android.opengl.Matrix.scaleM(model,0,.16f,.92f,.16f);android.opengl.Matrix.multiplyMM(mvp,0,view,0,model,0);android.opengl.Matrix.multiplyMM(mvp,0,proj,0,mvp,0);sphere.draw(program,mvp,model,0xFFFFEEEE.toInt(),0xFFFF4058.toInt(),0xFF8B061B.toInt(),0xFFFF173D.toInt())}
        private fun makeProgram(v:String,f:String):Int{fun sh(t:Int,s:String):Int{val id=android.opengl.GLES20.glCreateShader(t);android.opengl.GLES20.glShaderSource(id,s);android.opengl.GLES20.glCompileShader(id);return id};val p=android.opengl.GLES20.glCreateProgram();android.opengl.GLES20.glAttachShader(p,sh(android.opengl.GLES20.GL_VERTEX_SHADER,v));android.opengl.GLES20.glAttachShader(p,sh(android.opengl.GLES20.GL_FRAGMENT_SHADER,f));android.opengl.GLES20.glLinkProgram(p);return p}
        inner class Sphere(val seg:Int,val rings:Int){val vb:java.nio.FloatBuffer;val nb:java.nio.FloatBuffer;val count:Int
            init{val vs=ArrayList<Float>();val ns=ArrayList<Float>();for(y in 0..rings){val v=y.toFloat()/rings;val ph=(v*PI).toFloat();for(x in 0..seg){val u=x.toFloat()/seg;val th=(u*2*PI).toFloat();val sx=sin(ph)*cos(th);val sy=cos(ph);val sz=sin(ph)*sin(th);vs.add(sx);vs.add(sy);vs.add(sz);ns.add(sx);ns.add(sy);ns.add(sz)}};val idx=ArrayList<Short>();for(y in 0 until rings)for(x in 0 until seg){val a0=(y*(seg+1)+x).toShort();val b=(a0+seg+1).toShort();idx.add(a0);idx.add(b);idx.add((a0+1).toShort());idx.add((a0+1).toShort());idx.add(b);idx.add((b+1).toShort())};val inter=FloatArray(idx.size*6);var k=0;for(i in idx){val ii=i.toInt();inter[k++]=vs[ii*3];inter[k++]=vs[ii*3+1];inter[k++]=vs[ii*3+2];inter[k++]=ns[ii*3];inter[k++]=ns[ii*3+1];inter[k++]=ns[ii*3+2]};val bb=java.nio.ByteBuffer.allocateDirect(inter.size*4).order(java.nio.ByteOrder.nativeOrder());bb.asFloatBuffer().put(inter).position(0);vb=bb.asFloatBuffer();val nbuf=java.nio.ByteBuffer.allocateDirect(inter.size*4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();for(i in inter.indices step 6){nbuf.put(inter[i+3]);nbuf.put(inter[i+4]);nbuf.put(inter[i+5])};nbuf.position(0);nb=nbuf;count=idx.size}
            fun draw(pr:Int,mvp:FloatArray,mod:FloatArray,a1:Int,b:Int,c:Int,g:Int){android.opengl.GLES20.glUseProgram(pr);fun loc(n:String)=android.opengl.GLES20.glGetUniformLocation(pr,n);val ap=android.opengl.GLES20.glGetAttribLocation(pr,"aPos");val an=android.opengl.GLES20.glGetAttribLocation(pr,"aNormal");vb.position(0);android.opengl.GLES20.glEnableVertexAttribArray(ap);android.opengl.GLES20.glVertexAttribPointer(ap,3,android.opengl.GLES20.GL_FLOAT,false,24,vb);nb.position(0);android.opengl.GLES20.glEnableVertexAttribArray(an);android.opengl.GLES20.glVertexAttribPointer(an,3,android.opengl.GLES20.GL_FLOAT,false,24,vb.apply { position(3) });android.opengl.GLES20.glUniformMatrix4fv(loc("uMVP"),1,false,mvp,0);android.opengl.GLES20.glUniformMatrix4fv(loc("uModel"),1,false,mod,0);fun rgb(x:Int)=floatArrayOf(((x shr 16)and 255)/255f,((x shr 8)and 255)/255f,(x and 255)/255f);android.opengl.GLES20.glUniform3fv(loc("uA"),1,rgb(a1),0);android.opengl.GLES20.glUniform3fv(loc("uB"),1,rgb(b),0);android.opengl.GLES20.glUniform3fv(loc("uC"),1,rgb(c),0);android.opengl.GLES20.glUniform3fv(loc("uGlow"),1,rgb(g),0);android.opengl.GLES20.glDrawArrays(android.opengl.GLES20.GL_TRIANGLES,0,count);android.opengl.GLES20.glDisableVertexAttribArray(ap);android.opengl.GLES20.glDisableVertexAttribArray(an)}
        }
    }
}
