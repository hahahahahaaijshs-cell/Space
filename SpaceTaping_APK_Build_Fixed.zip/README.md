# Galactic Spin — AndroidIDE Build Fix

This is the corrected Galactic Spin project.

## Build compatibility
- Android Gradle Plugin 8.7.3
- Kotlin 1.9.24
- Compile/Target SDK 35
- Java/Kotlin JVM target 17
- Android Canvas + OpenGL ES 2.0 only; no external runtime game engine

## Important fixes
- Removed Kotlin 2.x / AGP combination that can be problematic in AndroidIDE setups.
- Replaced Kotlin JVM toolchain configuration with explicit JVM 17 target.
- Fixed the OpenGL normal-buffer attribute setup.
- Fixed ball-shop unlocking so credits are actually spent when a ball is unlocked.
- Added safer equipped-ball bounds.

Open the `GalacticSpin_Premium_Fixed` folder as the project root, then Sync/Build.
